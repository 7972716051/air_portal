from django.contrib import admin
from .models import Booking, Passenger
admin.site.register([Booking, Passenger])
